const products = [
  {
    name: "Portrait of Marten Soolmans",
    image: "images/105070.jpg",
    price: 75,
    quantity: 3
  },
  {
    name: "View of Houses in Delft",
    image: "images/106060.jpg",
    price: 125,
    quantity: 1
  },
  {
    name: "Woman Reading a Letter",
    image: "images/106050.jpg",
    price: 100,
    quantity: 2
  }
];